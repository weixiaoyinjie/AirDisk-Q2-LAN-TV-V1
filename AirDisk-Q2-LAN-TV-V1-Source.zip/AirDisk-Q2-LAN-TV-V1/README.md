# AirDisk Q2 LAN / Google TV Remote V1.0

**一个 APK 同时安装在安卓手机和 Google TV**，并通过 Wi-Fi/以太网局域网直接使用 AirDisk Q2 的 SMB 文件共享。没有互联网也可工作。无需厂商云、无需付费 API。

## 功能

- 自动扫描当前 `/24` IPv4 子网的 SMB 445/139 端口，手选确认的 AirDisk IP（扫描结果仅是 SMB 候选服务，不保证型号识别）。
- 浏览 SMB 共享、文件夹，递归扫描最多 2000 个视频，手机端展示可点击播放按钮。
- Google TV 端开启 HTTP 局域网接收器（18888），6 位 PIN 校验，手机遥控发送视频 SMB 路径。**SMB 密码不通过遥控指令发送**，电视端单独配置 SMB 凭据。
- Google TV 本地 HTTP 18889 端口将 SMB 流转为支持 Range/seek 的 HTTP，优先用 MX Player Pro 播放，其次 VLC。
- 断网时可通过本地路由器继续访问 SMB 视频；公网 IP 手动查询仅在有网时使用。
- BT 下载按钮可打开 AirDisk 官方 PC 软件提供的本地 BT 页面（需在 App 中填入官方给出的 URL，不伪造 API 地址）。

## 快速使用

1. 在 DM 云盘 HDD 原厂 App 设备设置中开启 **SAMBA**，根据盒子访问密码设置 SMB 登录。若无法枚举 SMB 共享根目录，可在「共享目录」手填 `AirDisk` 或实际的共享名。部分 AirDisk HDD 旧系列的 SMB 用户名是 `AirDisk`；如果 Q2 不同，以设备实际为准。
2. 手机和 Q2 连在同一个路由器 LAN（Wi-Fi 或有线，**路由器无互联网也能用**）。手机安装 APK，点击「自动扫描局域网 SMB IP」并选择 Q2。第一次可用截图确认的 `192.168.0.119` 尝试。
3. Google TV 安装相同 APK，输入相同 AirDisk SMB 用户名、密码，并点击「启动 TV 接收器」。**保持接收器画面在前台**以避免 Android 后台启动其他 App 的限制。记录 TV 上显示的 IP、6 位 PIN。
4. 手机上填入 Google TV IP 和 PIN，先点「发送测试」，再点「生成完整视频目录」。选择视频 → 「在 Google TV 播放」。
5. TV 端建议安装 `MX Player Pro` 或 `VLC`。它们的具体行为取决于版本、容器格式和电视解码能力。
6. 若无互联网也连不上：确认路由器 LAN 仍工作、手机电视在同一网段、未启用 AP isolation、AirDisk SAMBA 服务实际运行、SMB 账户正确。厂商远程云显示离线不等于局域网不可访问。

## BT 下载

AirDisk Q2 官方资料确认通过原厂 App 开启 BT 下载，原厂电脑客户端可复制一个浏览器管理链接。请把**设备当前对应的完整 URL**粘贴至「BT 网页地址」。本版本只打开经过确认的本地 BT 页面，不猜测私有 HTTP API 的端口或 URL，也不承诺在没有互联网时还能获取 BT 对等节点/下载数据。

## 外网

公网 IP 是当前手机默认互联网出口的 IP，**不是 Q2 的独立公网 IP**。没有互联网时没有可用的公网连接；远程访问依赖厂商服务或安全 VPN 配置。不要直接将 SMB 445 端口暴露到公网。应用仅在你手动按下公网 IP 按钮时访问第三方 `api.ipify.org`。

## GitHub Actions 编译

将**ZIP 解压后的所有文件**上传至新建仓库根目录（GitHub 不会自动解压上传的 ZIP），进入 `Actions > Build AirDisk Q2 LAN TV APK > Run workflow`。编译后下载 Artifacts 中 `AirDisk-Q2-LAN-TV-debug`，里面是 `app-debug.apk`。请自行按设备兼容情况实测。

## 安全与限制

- 控制通道使用内网 HTTP + 6 位 PIN，**未使用 TLS 加密**。仅在可信任的家庭 LAN 使用，勿公开映射 18888 端口。SMB 凭据以 app 私有 SharedPreferences 保存在每台设备上，未使用 Android Keystore 加密，避免在共享/不可信设备上输入敏感密码。
- 为兼容旧型号允许 SMB1；其安全性比 SMB2/3 差，不应暴露到外网。扫描仅默认当前 `/24` 子网；复杂多网段、路由器 AP 隔离和设备依赖云鉴权场景需要额外改进。
- Android 10+ 对后台 Activity 启动有限制，所以电视端的接收 App **建议打开并保持在前台**；若电视正在运行其他应用，系统可能不准本 App 自动启动 MX Player/VLC。此时回到 TV 接收器界面再触发播放。
- 这是一版供 GitHub Actions **构建与实际设备验证的源码**，未对你的 Q2 硬件做现场测试。播放兼容性与固件版本有关系。
- 扫描所有硬盘目录在深目录/数千视频时可能耗时，v1 以简单可靠为目标，不含海报、字幕索引、缓存持久化或 BT 私有接口任务 CRUD。

## 根据官方资料

- AirDisk Q3X/Q2 BT 下载说明: https://test.airdisk.cc/document/103.html
- AirDisk HDD SMB 接入官方说明（相邻系列）: https://test.airdisk.cc/document/28.html
- jCIFS-NG SMB2/SMB1 client: https://github.com/AgNO3/jcifs-ng
