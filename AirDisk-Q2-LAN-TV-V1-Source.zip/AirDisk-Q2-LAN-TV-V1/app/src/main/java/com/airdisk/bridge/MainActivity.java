package com.airdisk.bridge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.URL;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout root, filesBox, scanBox;
    private TextView info, pathDisplay, tvStatus;
    private EditText smbIp, smbUser, smbPass, smbShare, tvIp, tvPin, btUrl;
    private String folderPath = "";
    private volatile boolean visible = false;
    private static MainActivity foreground;
    private final ExecutorService pool = Executors.newCachedThreadPool();

    static MainActivity currentForeground() { return foreground; }
    SharedPreferences prefs() { return getSharedPreferences("settings", Context.MODE_PRIVATE); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bindToLan();
        buildUi();
        receivePlayback(getIntent());
    }
    @Override protected void onResume() { super.onResume(); visible=true; foreground=this; }
    @Override protected void onPause() { visible=false; if (foreground==this) foreground=null; super.onPause(); }
    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); receivePlayback(intent); }
    private void receivePlayback(Intent intent) {
        if (intent != null && "com.airdisk.bridge.PLAY".equals(intent.getAction())) {
            String file = intent.getStringExtra("file");
            if (file != null) ui.postDelayed(() -> launchPlayer(file), 300);
        }
    }

    private TextView text(String t, int sp) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(sp); v.setPadding(8,10,8,10);
        root.addView(v); return v;
    }
    private EditText field(String label, String value, boolean secret) {
        text(label, 14);
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setTextSize(16); e.setText(value);
        if (secret) e.setInputType(129);
        root.addView(e);
        return e;
    }
    private Button button(LinearLayout target, String title, View.OnClickListener action) {
        Button b=new Button(this); b.setText(title); b.setAllCaps(false); b.setOnClickListener(action);
        target.addView(b); return b;
    }
    private void save() {
        prefs().edit().putString("ip", smbIp.getText().toString().trim())
            .putString("user", smbUser.getText().toString().trim())
            .putString("pass", smbPass.getText().toString())
            .putString("share", smbShare.getText().toString().trim())
            .putString("tvip", tvIp.getText().toString().trim())
            .putString("pinTarget", tvPin.getText().toString().trim())
            .putString("bt", btUrl.getText().toString().trim()).apply();
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,18,18,18);
        scroll.addView(root); setContentView(scroll);
        text("AirDisk Q2 · 无网硬盘与 TV 控制 V1.0", 22);
        text("同一 APK 可装手机与 Google TV。纯局域网 SMB 不依赖厂商云。", 14);
        String defaultIp=prefs().getString("ip","192.168.0.119");
        smbIp=field("AirDisk 局域网 IP（断电重启后可重新扫描）",defaultIp,false);
        smbUser=field("SMB 用户名（官方旧系列一般使用 AirDisk）",prefs().getString("user","AirDisk"),false);
        smbPass=field("SMB 密码（输入你的设备访问密码）",prefs().getString("pass",""),true);
        smbShare=field("共享目录（不确定时留空；如 AirDisk 或 AirDisk/Q2-A）",prefs().getString("share",""),false);
        button(root,"保存 SMB 设置",v -> { save(); note("已保存设备设置"); });
        button(root,"自动扫描局域网 SMB IP",v -> { save(); scanSubnet(); });
        scanBox=new LinearLayout(this); scanBox.setOrientation(LinearLayout.VERTICAL); root.addView(scanBox);
        button(root,"连接硬盘 · 查看文件夹",v -> {save(); folderPath=shareRoot(); listCurrent();});
        button(root,"生成完整视频目录（最多 2000 个）",v -> {save(); scanVideos();});
        pathDisplay=text("目录：尚未连接",13);
        filesBox=new LinearLayout(this); filesBox.setOrientation(LinearLayout.VERTICAL); root.addView(filesBox);

        text("──────── Google TV 远程播放 ────────",18);
        tvIp=field("Google TV 的局域网 IP（在电视端可查看）",prefs().getString("tvip",""),false);
        tvPin=field("电视端显示的 6 位配对口令",prefs().getString("pinTarget",""),false);
        button(root,"发送测试：检查电视接收器",v -> { save(); testTv(); });
        text("电视安装同一个 APK，开启下方接收器。电视端也要填写 AirDisk 的 SMB 用户名和密码。",13);
        tvStatus=text("本机 IP："+localIp()+"  |  接收端口：18888",14);
        button(root,"在这台设备启动 TV 接收器",v -> { save(); startReceiver(); });
        button(root,"停止本机 TV 接收器",v -> {
            stopService(new Intent(this, BridgeService.class)); note("已发送停止指令");
        });
        button(root,"重新生成本机配对口令",v -> {
            int pin=100000+new SecureRandom().nextInt(900000);
            prefs().edit().putString("serverPin",Integer.toString(pin)).apply();
            tvStatus.setText("本机 IP："+localIp()+"   口令："+pin+"   端口：18888");
        });
        showServerPin();
        text("──────── BT 与网络状态 ────────",18);
        btUrl=field("AirDisk BT 网页地址（从官方电脑客户端复制）",prefs().getString("bt",""),false);
        button(root,"打开 BT 下载网页",v -> {
            save(); String url=btUrl.getText().toString().trim();
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                note("请先从 AirDisk 官方电脑客户端复制 BT 网页地址（含 http://）。"); return;
            }
            try {startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
            catch(Exception e){note("无法打开网页："+e.getMessage());}
        });
        button(root,"检查互联网与公网 IP（使用 ipify 第三方服务）",v -> checkWan());
        info=text("准备就绪。无互联网时只需连上同一个 Wi-Fi/有线局域网。",14);
        text("注意：设备 SMB 若未开启、盒子未取得局域网 IP 或路由器启用客户端隔离，App 无法绕过硬件限制。TV 在其他应用后台时可能受 Android 启动限制，建议让接收器界面保持开启。",12);
    }
    private void showServerPin() {
        String pin=prefs().getString("serverPin","");
        if (pin.isEmpty()) { pin=Integer.toString(100000+new SecureRandom().nextInt(900000)); prefs().edit().putString("serverPin",pin).apply(); }
        tvStatus.setText("本机 IP："+localIp()+"   本机口令："+pin+"   端口：18888");
    }
    private void note(String msg) { ui.post(() -> { info.setText(msg); Toast.makeText(this,msg,Toast.LENGTH_SHORT).show(); }); }
    private void async(Callable<String> work) {
        pool.execute(() -> { try { String msg=work.call(); note(msg); }
            catch(Exception e){ note("操作失败："+e.getClass().getSimpleName()+" - "+e.getMessage()); } });
    }
    private String shareRoot() {
        String r=SmbClient.root(smbIp.getText().toString());
        String share=smbShare.getText().toString().trim().replace('\\','/');
        while(share.startsWith("/"))share=share.substring(1);
        while(share.endsWith("/"))share=share.substring(0,share.length()-1);
        if(share.isEmpty())return r;
        return r+share+"/";
    }
    private void listCurrent() {
        final String user=smbUser.getText().toString(), pass=smbPass.getText().toString();
        final String path=folderPath;
        pathDisplay.setText("正在读取："+path);
        async(() -> {
            List<SmbClient.Entry> entries=SmbClient.list(path,user,pass);
            ui.post(() -> { filesBox.removeAllViews(); pathDisplay.setText("当前目录："+path);
                if (!path.equals(shareRoot())) {
                    button(filesBox,"⬆ 返回上一级",v -> {folderPath=parentPath(folderPath);listCurrent();});
                }
                for (SmbClient.Entry e: entries) {
                    if (e.folder) button(filesBox,"📁 "+e.name,v -> {folderPath=e.path; listCurrent();});
                    else if (SmbClient.video(e.name)) addVideo(e);
                }
            });
            return "已读取目录，找到 "+entries.size()+" 个条目（只显示目录和视频文件）";
        });
    }
    private String parentPath(String path) {
        String rootPath=shareRoot();
        String s=path.endsWith("/")?path.substring(0,path.length()-1):path;
        int i=s.lastIndexOf('/');
        String out=s.substring(0,i+1);
        return out.length()<rootPath.length()?rootPath:out;
    }
    private void addVideo(SmbClient.Entry e) {
        LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.VERTICAL);
        TextView t=new TextView(this); t.setText("🎞 "+e.name); t.setTextSize(15); t.setPadding(8,10,8,0);line.addView(t);
        button(line,"在 Google TV 播放",v -> {save(); remotePlay(e.path);});
        button(line,"在本手机播放",v -> {save(); startReceiver(); ui.postDelayed(() -> launchPlayer(e.path),700);});
        filesBox.addView(line);
    }
    private void scanVideos() {
        final String path=shareRoot();
        final String user=smbUser.getText().toString(), pass=smbPass.getText().toString();
        info.setText("正在递归扫描视频目录；大容量硬盘可能较慢……");
        async(() -> {
            List<SmbClient.Entry> all=SmbClient.allVideos(path,user,pass,2000);
            ui.post(() -> {filesBox.removeAllViews();pathDisplay.setText("视频库 · "+all.size()+" 个视频");
                for(SmbClient.Entry e:all) addVideo(e);
            });
            return "视频库生成成功："+all.size()+" 个视频（上限 2000）";
        });
    }
    private void remotePlay(String path) {
        final String host=tvIp.getText().toString().trim(), pin=tvPin.getText().toString().trim();
        async(() -> {
            String url="http://"+host+":18888/play?key="+enc(pin)+"&file="+enc(path);
            return get(url);
        });
    }
    private void testTv() {
        async(() -> get("http://"+tvIp.getText().toString().trim()+":18888/status"));
    }
    static String enc(String text) throws Exception {return URLEncoder.encode(text,"UTF-8");}
    private static String get(String target) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(target).openConnection();
        c.setConnectTimeout(3500);c.setReadTimeout(5000);
        try {
            int code=c.getResponseCode();
            BufferedReader r=new BufferedReader(new InputStreamReader(code<400?c.getInputStream():c.getErrorStream()));
            String line=r.readLine();r.close();return "HTTP "+code+": "+line;
        } finally { c.disconnect(); }
    }
    private void startReceiver() {
        try {
            Intent i=new Intent(this,BridgeService.class);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
            showServerPin(); note("正在启动本地接收器 · "+localIp()+":18888");
        } catch(Exception e){note("启动接收器失败："+e.getMessage());}
    }
    void playIncoming(String file) { ui.post(() -> launchPlayer(file)); }
    private void launchPlayer(String file) {
        if (file==null || !file.startsWith("smb://")) {note("拒绝无效文件路径");return;}
        try {
            String url="http://127.0.0.1:18889/stream?file="+enc(file);
            Uri uri=Uri.parse(url);
            // Prefer MX Player Pro, then VLC; otherwise Android video intent.
            for(String pkg:new String[]{"com.mxtech.videoplayer.pro","org.videolan.vlc",""}){
                Intent play=new Intent(Intent.ACTION_VIEW);
                play.setDataAndType(uri,"video/*");play.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if(!pkg.isEmpty())play.setPackage(pkg);
                try {startActivity(play);note("已发送播放请求："+file.substring(file.lastIndexOf('/')+1));return;}
                catch(Exception ignored) { }
            }
            note("未找到可用播放器，请安装 MX Player Pro 或 VLC。");
        } catch(Exception e){note("播放失败："+e.getMessage());}
    }
    private void bindToLan() {
        // Keep SMB requests on the local WLAN even if mobile-data is the default internet route.
        try {
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            for(Network network:cm.getAllNetworks()) {
                NetworkCapabilities caps=cm.getNetworkCapabilities(network);
                if(caps!=null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                     caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))) {
                    cm.bindProcessToNetwork(network);
                    return;
                }
            }
        }catch(Exception ignored){}
    }
    static String localIp() {
        try {
            // Prefer Wi-Fi/Ethernet over a cellular 10.x address.
            for(int pass=0;pass<2;pass++){
                Enumeration<NetworkInterface> interfaces=NetworkInterface.getNetworkInterfaces();
                while(interfaces.hasMoreElements()){
                    NetworkInterface n=interfaces.nextElement();
                    if(!n.isUp()||n.isLoopback())continue;
                    String name=n.getName().toLowerCase(java.util.Locale.ROOT);
                    boolean lan=name.startsWith("wlan")||name.startsWith("eth")||name.startsWith("en")||name.startsWith("ap");
                    if((pass==0)!=lan)continue;
                    Enumeration<java.net.InetAddress> ips=n.getInetAddresses();
                    while(ips.hasMoreElements()){
                        java.net.InetAddress a=ips.nextElement();
                        if(a instanceof Inet4Address && a.isSiteLocalAddress() && !a.isLoopbackAddress())return a.getHostAddress();
                    }
                }
            }
        }catch(Exception ignored){}
        return "未连接局域网";
    }
    private void scanSubnet() {
        String my=localIp();
        String ip = my.equals("未连接局域网")?smbIp.getText().toString().trim():my;
        if(!ip.matches("\\d+\\.\\d+\\.\\d+\\.\\d+")){ note("无法识别局域网 IPv4");return; }
        String prefix=ip.substring(0,ip.lastIndexOf('.')+1);
        info.setText("扫描 "+prefix+"0/24 的 445 和 139 端口……");
        pool.execute(() -> {
            ExecutorService scan=Executors.newFixedThreadPool(36);
            List<Future<String>> futures=new ArrayList<>();
            for(int i=1;i<=254;i++){
                final String host=prefix+i;
                futures.add(scan.submit(() -> {
                    for(int port:new int[]{445,139}){
                        try(Socket socket=new Socket()){
                            socket.connect(new InetSocketAddress(host,port),220);return host+" (SMB:"+port+")";
                        }catch(Exception ignored){}
                    }
                    return null;
                }));
            }
            ArrayList<String> found=new ArrayList<>();
            for(Future<String> future:futures){try{String s=future.get();if(s!=null)found.add(s);}catch(Exception ignored){}}
            scan.shutdownNow();Collections.sort(found);
            ui.post(() -> {
                scanBox.removeAllViews();
                if(found.isEmpty()) {note("未检测到 SMB 服务。检查盒子供电、SMB 开关、手机 Wi-Fi。 ");return;}
                for(String foundIp:found){
                    String address=foundIp.split(" ")[0];
                    button(scanBox,"使用 "+foundIp,v -> {smbIp.setText(address);save();folderPath=shareRoot();listCurrent();});
                }
                info.setText("发现 "+found.size()+" 个 SMB 服务（不一定全是 AirDisk）；请选择目标设备");
            });
        });
    }
    private void checkWan() {
        ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        NetworkCapabilities nc=cm.getNetworkCapabilities(cm.getActiveNetwork());
        boolean connected = nc!=null&&nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        if(!connected){note("没有已验证的互联网连接。局域网 SMB 可以继续使用；此时无法查询公网 IP。");return;}
        async(() -> "外网查询（当前设备出口 IP）："+get("https://api.ipify.org"));
    }
    @Override protected void onDestroy(){pool.shutdownNow();super.onDestroy();}
}
