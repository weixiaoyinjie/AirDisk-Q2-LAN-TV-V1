package com.airdisk.bridge;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Locale;
import jcifs.CIFSContext;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbRandomAccessFile;

final class SmbClient {
    private SmbClient() {}

    static CIFSContext context(String user, String password) throws Exception {
        Properties props = new Properties();
        // Allow older SMB1 firmware as well as SMB2; do not expose SMB to the Internet.
        props.setProperty("jcifs.smb.client.minVersion", "SMB1");
        props.setProperty("jcifs.smb.client.maxVersion", "SMB210");
        props.setProperty("jcifs.smb.client.connTimeout", "5000");
        props.setProperty("jcifs.smb.client.responseTimeout", "12000");
        CIFSContext base = new BaseContext(new PropertyConfiguration(props));
        return base.withCredentials(new NtlmPasswordAuthenticator("", user, password));
    }

    static String root(String ip) { return "smb://" + ip.trim() + "/"; }

    static List<Entry> list(String path, String user, String pass) throws Exception {
        List<Entry> out = new ArrayList<>();
        try (SmbFile directory = new SmbFile(path, context(user,pass))) {
            for (SmbFile child : directory.listFiles()) {
                try {
                    boolean isDir = child.isDirectory();
                    String name = child.getName();
                    String address = child.getPath();
                    out.add(new Entry(name, address, isDir));
                } finally { child.close(); }
            }
        }
        Collections.sort(out, (a,b) -> {
            if (a.folder != b.folder) return a.folder ? -1 : 1;
            return a.name.compareToIgnoreCase(b.name);
        });
        return out;
    }

    static List<Entry> allVideos(String root, String user, String pass, int max) throws Exception {
        List<Entry> result = new ArrayList<>();
        walk(root, user, pass, result, max, 0);
        return result;
    }

    private static void walk(String path, String user, String pass, List<Entry> result, int max, int depth) throws Exception {
        if (depth > 12 || result.size() >= max) return;
        for (Entry e : list(path, user, pass)) {
            if (result.size() >= max) return;
            if (e.folder) {
                try { walk(e.path, user, pass, result, max, depth + 1); }
                catch (Exception ignored) { /* inaccessible folder: scan other folders */ }
            } else if (video(e.name)) result.add(e);
        }
    }

    static boolean video(String filename) {
        String s = filename.toLowerCase(Locale.ROOT);
        return s.endsWith(".mkv") || s.endsWith(".mp4") || s.endsWith(".avi") ||
            s.endsWith(".mov") || s.endsWith(".ts") || s.endsWith(".m4v") ||
            s.endsWith(".wmv") || s.endsWith(".webm") || s.endsWith(".flv") || s.endsWith(".mpg");
    }

    static SmbRandomAccessFile open(String path, String user, String pass) throws Exception {
        return new SmbRandomAccessFile(new SmbFile(path, context(user, pass)), "r");
    }

    static final class Entry {
        final String name, path;
        final boolean folder;
        Entry(String n, String p, boolean f) { name=n; path=p; folder=f; }
    }
}
