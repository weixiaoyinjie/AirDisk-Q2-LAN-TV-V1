package com.airdisk.bridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.net.Uri;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import jcifs.smb.SmbRandomAccessFile;

public class BridgeService extends Service {
    private volatile boolean active;
    private ServerSocket control, stream;
    private Thread controlThread,streamThread;
    private final ExecutorService clients=Executors.newFixedThreadPool(8);

    @Override public IBinder onBind(Intent intent){return null;}
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        foregroundNotification("接收器正在局域网运行");
        if (!active) {
            active=true;
            controlThread=new Thread(() -> listen(18888,false),"control-18888");
            streamThread=new Thread(() -> listen(18889,true),"stream-18889");
            controlThread.start();streamThread.start();
        }
        return START_STICKY;
    }
    private void foregroundNotification(String title){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(
            new NotificationChannel("bridge","AirDisk 本地接收器",NotificationManager.IMPORTANCE_LOW));
        Intent open=new Intent(this,MainActivity.class);
        int flags=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi=PendingIntent.getActivity(this,12,open,flags);
        Notification n=new Notification.Builder(this,"bridge")
            .setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("AirDisk Q2 · TV 本地接收器")
            .setContentText(title).setContentIntent(pi).setOngoing(true).build();
        startForeground(13,n);
    }
    private void listen(int port,boolean loopback){
        try(ServerSocket s=new ServerSocket()){
            if(loopback)stream=s; else control=s;
            s.setReuseAddress(true);
            InetAddress bind=InetAddress.getByName(loopback?"127.0.0.1":"0.0.0.0");
            s.bind(new InetSocketAddress(bind,port));
            while(active){
                Socket client=s.accept();
                clients.execute(() -> handle(client,loopback));
            }
        }catch(Exception e){android.util.Log.e("AirDiskBridge","Listener failed on "+port,e);}
    }
    private String line(InputStream in) throws Exception{
        java.io.ByteArrayOutputStream b=new java.io.ByteArrayOutputStream();
        int ch;
        while((ch=in.read())!=-1){
            if(ch=='\n')break;
            if(ch!='\r')b.write(ch);
            if(b.size()>16384)throw new IllegalArgumentException("HTTP line too long");
        }
        return b.toString("UTF-8");
    }
    private static Map<String,String> query(String raw)throws Exception{
        Map<String,String> m=new HashMap<>();
        int q=raw.indexOf('?');if(q<0)return m;
        for(String s:raw.substring(q+1).split("&")){
            String[] p=s.split("=",2);
            if(p.length==2)m.put(URLDecoder.decode(p[0],"UTF-8"),URLDecoder.decode(p[1],"UTF-8"));
        }
        return m;
    }
    private void handle(Socket socket,boolean localStream){
        try(Socket s=socket){
            s.setSoTimeout(15000);
            InputStream in=new BufferedInputStream(s.getInputStream());
            OutputStream out=new BufferedOutputStream(s.getOutputStream());
            String first=line(in);if(first.isEmpty())return;
            String[] request=first.split(" ");
            if(request.length<2||!request[0].equals("GET")){respond(out,405,"Only GET supported");return;}
            String range="";String header;
            for(int i=0;i<60 && !(header=line(in)).isEmpty();i++){
                if(header.toLowerCase(Locale.ROOT).startsWith("range:"))range=header.substring(6).trim();
            }
            String path=request[1];
            if(localStream){
                if(!path.startsWith("/stream?")){respond(out,404,"Not found");return;}
                String file=query(path).get("file");
                if(!validFile(file)){respond(out,400,"Invalid SMB file");return;}
                streamFile(out,file,range);
            } else if(path.startsWith("/status")){
                respond(out,200,"AirDisk bridge online; host="+MainActivity.localIp()+"; port=18888");
            } else if(path.startsWith("/play?")){
                Map<String,String> p=query(path);
                SharedPreferences prefs=getSharedPreferences("settings",MODE_PRIVATE);
                if(!prefs.getString("serverPin","-").equals(p.get("key"))){respond(out,403,"Incorrect TV pairing PIN");return;}
                String file=p.get("file");
                if(!validFile(file)){respond(out,400,"Only local SMB URLs allowed");return;}
                MainActivity visible=MainActivity.currentForeground();
                if(visible!=null){
                    visible.playIncoming(file);
                    respond(out,200,"TV playback requested: "+file.substring(file.lastIndexOf('/')+1));
                } else {
                    // Android 10+ limits background Activity launches. Try, but never claim success.
                    try{
                        Intent open=new Intent(this,MainActivity.class);
                        open.setAction("com.airdisk.bridge.PLAY");open.putExtra("file",file);
                        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(open);
                    }catch(Exception ignored){}
                    respond(out,202,"Command accepted; open receiver on TV if Android blocks background launch");
                }
            } else respond(out,404,"Not found");
        }catch(Exception e){android.util.Log.w("AirDiskBridge","HTTP request: "+e.getMessage());}
    }
    private static boolean validFile(String file){
        if(file==null || !file.startsWith("smb://"))return false;
        try{
            Uri u=Uri.parse(file);
            String host=u.getHost();
            if(host==null || !host.matches("\\d+\\.\\d+\\.\\d+\\.\\d+"))return false;
            java.net.InetAddress addr=java.net.InetAddress.getByName(host);
            // Only RFC1918 private addresses. Do not use service as an Internet fetch proxy.
            byte[] b=addr.getAddress();if(b.length!=4)return false;
            int a=b[0]&255,c=b[1]&255;
            return a==10 || (a==172 && c>=16 && c<=31) || (a==192 && c==168);
        }catch(Exception ignored){return false;}
    }
    private static String mime(String f){
        String s=f.toLowerCase(Locale.ROOT);
        if(s.endsWith(".mp4")||s.endsWith(".m4v"))return "video/mp4";
        if(s.endsWith(".mkv"))return "video/x-matroska";
        if(s.endsWith(".avi"))return "video/x-msvideo";
        if(s.endsWith(".ts"))return "video/mp2t";
        return "application/octet-stream";
    }
    private void streamFile(OutputStream out,String file,String range) throws Exception{
        SharedPreferences prefs=getSharedPreferences("settings",MODE_PRIVATE);
        String user=prefs.getString("user","AirDisk"),pass=prefs.getString("pass","");
        try(SmbRandomAccessFile source=SmbClient.open(file,user,pass)){
            long length=source.length();if(length<=0){respond(out,404,"Empty file");return;}
            long from=0,to=length-1;
            boolean partial=false;
            if(range!=null&&range.startsWith("bytes=")){
                String spec=range.substring(6).split(",")[0];
                String[] span=spec.split("-",-1);
                if(span.length==2){
                    if(span[0].isEmpty()){
                        long suffix=Long.parseLong(span[1]);from=Math.max(0,length-suffix);
                    }else from=Long.parseLong(span[0]);
                    if(!span[1].isEmpty()&&!span[0].isEmpty())to=Math.min(length-1,Long.parseLong(span[1]));
                    partial=true;
                }
            }
            if(from<0||from>=length||from>to){
                String header="HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */"+length+"\r\nContent-Length: 0\r\n\r\n";
                out.write(header.getBytes(StandardCharsets.US_ASCII));out.flush();return;
            }
            long bytes=to-from;
            bytes+=1;
            String headers="HTTP/1.1 "+(partial?"206 Partial Content":"200 OK")+"\r\n"+
                "Content-Type: "+mime(file)+"\r\n"+
                "Accept-Ranges: bytes\r\nContent-Length: "+bytes+"\r\n"+
                (partial?"Content-Range: bytes "+from+"-"+to+"/"+length+"\r\n":"")+
                "Cache-Control: no-store\r\nConnection: close\r\n\r\n";
            out.write(headers.getBytes(StandardCharsets.US_ASCII));out.flush();
            source.seek(from);
            byte[] buf=new byte[64*1024];long left=bytes;
            while(left>0){
                int n=source.read(buf,0,(int)Math.min(buf.length,left));
                if(n<=0)break;
                out.write(buf,0,n);left-=n;
            }
            out.flush();
        }catch(Exception e){
            // If we have not sent headers yet this is a clean failure; if already streaming it closes.
            android.util.Log.w("AirDiskBridge","Stream failed",e);
            throw e;
        }
    }
    private static void respond(OutputStream out,int code,String message)throws Exception{
        String status=code==200?"OK":code==202?"Accepted":code==403?"Forbidden":"Error";
        byte[] body=(message+"\n").getBytes(StandardCharsets.UTF_8);
        String h="HTTP/1.1 "+code+" "+status+"\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: "+body.length+"\r\nConnection: close\r\n\r\n";
        out.write(h.getBytes(StandardCharsets.US_ASCII));out.write(body);out.flush();
    }
    @Override public void onDestroy(){
        active=false;
        try{if(control!=null)control.close();}catch(Exception ignored){}
        try{if(stream!=null)stream.close();}catch(Exception ignored){}
        clients.shutdownNow();super.onDestroy();
    }
}
